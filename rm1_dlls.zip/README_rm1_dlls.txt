
Thu Apr 28 14:06:36 PDT 2016

These .dlls must be in the same directory as RacerMateOne.exe

racermate.dll is the serial and wifi CT/velotron drivers

qt560.zip contains the Qt runtimes for racermate.dll
Be sure to preserve the platforms directory

Archive:  qt560.zip
  Length      Date    Time    Name
---------  ---------- -----   ----
        0  2016-03-22 14:19   platforms/
    30720  2016-03-03 07:29   platforms/qminimal.dll
  1021440  2016-03-03 07:30   platforms/qwindows.dll
   549376  2016-03-03 07:30   platforms/qoffscreen.dll
  4638208  2016-03-21 07:11   qt5core.dll
  5005824  2016-03-03 07:22   Qt5Gui.dll
   849408  2016-03-03 07:19   qt5network.dll
  4410880  2016-03-03 07:27   qt5widgets.dll
---------                     -------
 16505856                     8 files

