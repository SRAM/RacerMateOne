
Fri Apr 29 14:41:35 PDT 2016

These .dlls must be in the same directory as RacerMateOne.exe

racermate.dll is the serial and wifi CT/velotron drivers

It uses pcre3.dll, qt5core.dll and qt5network.dll
